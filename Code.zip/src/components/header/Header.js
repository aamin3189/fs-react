import React from 'react';
import './header.css';

function Header() {
  return (
      <h1 id="my-header">
          Full Stack Training - VI
      </h1>
  );
}

export default Header;